package com.baidu.test;

import com.baidu.pojo.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUser {
    @Test
    public void testUser(){
        //加载spring的全局配置文件
        ApplicationContext  context=new ClassPathXmlApplicationContext("applicationContext.xml");
        System.out.println(context);
        //第一种方法:根据id获取
        User user=(User) context.getBean("user");
        System.out.println(user);
        User user1=(User) context.getBean("user2");
        System.out.println(user1);
        //第二种方法获取:根据类型获取
//        User user2=context.getBean(User.class);
//        System.out.println(user2);
    }
}
